# Kit Modo Agêntico

Deixe a IA fazer. Você confere.

## O que tem aqui
- **Kit-Modo-Agentico.pdf** (e a mesma versão em **.html**, que abre no celular): 1 situação resolvida, 4 desafios, a caça ao erro e o semáforo de dados.
- **vendas_set_out_2026.xlsx** (e .csv): a planilha de treino. Os dados são fictícios.
- **skills/**: 3 skills para instalar hoje. Uma skill é uma instrução salva: você pede, ela faz, você confere.
  - Dicionário de dados: antes de analisar.
  - Comparador de períodos: durante a análise.
  - Revisor de relatório: antes de enviar.

## Como instalar uma skill
- **Claude:** Configurações → Capabilities → Skills → Upload skill. Envie o arquivo .zip da skill.
- **ChatGPT:** crie um Projeto e cole o arquivo instrucao-universal.md nas instruções.
- **Gemini:** Gems → Novo Gem. Cole o mesmo arquivo nas instruções.
- **Copilot:** Criar agente. Cole o mesmo arquivo nas instruções.

Use o .xlsx no Excel em português. O .csv usa ponto decimal.

modoagentico.com.br · instagram.com/modoagentico · linkedin.com/in/gggabrielbastos
