# Kit Modo Agêntico

Deixe a IA fazer. Você confere.

## O que tem aqui
- **Kit-Modo-Agentico.pdf**: 1 situação resolvida, 4 desafios, a caça ao erro e o semáforo de dados.
- **vendas_set_out_2026.xlsx** (e .csv): a planilha de treino. Os dados são fictícios.
- **agentes/**: 3 agentes para instalar hoje.
  - Dicionário de dados: antes de analisar.
  - Comparador de períodos: durante a análise.
  - Revisor de relatório: antes de enviar.

## Como instalar um agente
- **Claude:** Configurações → Capabilities → Skills → Upload skill. Envie o arquivo .zip do agente.
- **ChatGPT:** crie um Projeto e cole o arquivo instrucao-universal.md nas instruções.
- **Gemini:** Gems → Novo Gem. Cole o mesmo arquivo nas instruções.
- **Copilot:** Criar agente. Cole o mesmo arquivo nas instruções.

Use o .xlsx no Excel em português. O .csv usa ponto decimal.

modoagentico.com.br · @modoagentico
